from odoo import models, fields, api
from odoo.exceptions import UserError
from odoo.exceptions import ValidationError

class McmProduceCbcs(models.Model):
    _name = 'mcm.produce.cbcs'
    _description = 'Manufacturing CBCS Order'
    _rec_name = 'product_id'
    customer = fields.Char(default='Eisa Bhai')
    name = fields.Char(string='Reference', default='New', required=True, copy=False, readonly=True)
    product_id = fields.Many2one('product.product', string='Product', required=True)
    bom_id = fields.Many2one(
        'mcm.bom',
        string='Bill of Materials',
    )
    product_qty = fields.Float(string='Quantity', required=True, default=1.0)

    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('in_progress', 'In Progress'),
        ('done', 'Done'),
        ('unbuilt', 'Unbuilt'),
    ], default='draft', string='Status')

    line_ids = fields.One2many('mcm.produce.cbcs.line', 'order_id', string='Order Lines')
    phone = fields.Text(string='phone')

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('mcm.produce.cbcs') or 'New'
        return super().create(vals)

    @api.onchange('bom_id', 'product_qty')
    def _onchange_bom_id(self):
        if not self.bom_id:
            self.line_ids = [(5, 0, 0)]  # Clear all lines if BOM is cleared
            return

        # Set product from BOM
        self.product_id = self.bom_id.product_id

        # Clear all previous components
        self.line_ids = [(5, 0, 0)]

        # Scale component quantities based on the BOM's defined finished quantity
        multiplier = self.product_qty * (self.bom_id.quantity or 1.0)

        # Add BOM components
        self.line_ids = [
            (0, 0, {
                'product_id': line.product_id.id,
                'product_qty': line.quantity * multiplier,
            })
            for line in self.bom_id.bom_line_ids
        ]


        # self.line_ids = updated_lines

    def action_share_whattsapp(self):
        if not self.phone:
            raise ValidationError("Missing Phone Number")
        msg = "hi %s,Your Appointent Number is : %s, Thanks" % (self.customer, self.product_id)


        whatsapp_api_url = 'https://api.whatsapp.com/send?phone=%s&text=%s' % (self.phone, msg)

        return {
            'type' : 'ir.actions.act_url',
            'target' : 'new',
            'url' : whatsapp_api_url
        }

    def action_confirm(self):
        self.state = 'confirmed'

    def action_start(self):
        self.state = 'in_progress'

    def action_done(self):
        self.state = 'done'

    def action_cancel(self):
        self.state = 'draft'

    def action_unbuild(self):
        self.state = 'unbuilt'

    def action_produce(self):
        for rec in self:
            bom = rec.bom_id or self.env['mcm.bom'].search([('product_id', '=', rec.product_id.id)], limit=1)
            if not bom:
                raise UserError(f"No BOM defined for product: {rec.product_id.name}")

            scale = rec.product_qty  # Direct multiplier

            # Deduct raw materials (even if stock goes negative)
            for line in bom.bom_line_ids:
                required_qty = line.quantity * scale

                inventory = self.env['inventory.stock.line'].search([
                    ('product_id', '=', line.product_id.id)
                ], limit=1)

                if inventory:
                    inventory.quantity -= required_qty  # Allow negative quantity
                else:
                    # Create stock line with negative quantity
                    self.env['inventory.stock.line'].create({
                        'product_id': line.product_id.id,
                        'quantity': -required_qty
                    })

            # Add finished product
            finished_inv = self.env['inventory.stock.line'].search([
                ('product_id', '=', rec.product_id.id)
            ], limit=1)

            if finished_inv:
                finished_inv.quantity += rec.product_qty
            else:
                self.env['inventory.stock.line'].create({
                    'product_id': rec.product_id.id,
                    'quantity': rec.product_qty
                })

            rec.state = 'done'


class McmProduceCbcsLine(models.Model):
    _name = 'mcm.produce.cbcs.line'
    _description = 'CBCS Order Line'

    order_id = fields.Many2one('mcm.produce.cbcs', string='Order Reference', ondelete='cascade')
    product_id = fields.Many2one('product.product', string='Product', required=True)
    product_qty = fields.Float(string='Quantity', required=True, default=1.0)


class MCMBOM(models.Model):
    _name = 'mcm.bom'
    _description = 'Custom Bill of Materials'
    _rec_name = 'product_id'

    name = fields.Char(string="BOM Reference", required=True, default="New")
    product_id = fields.Many2one('product.product', string='Finished Product', required=True)
    quantity = fields.Float(string="Finished Quantity", required=True, default=1.0)
    bom_line_ids = fields.One2many('mcm.bom.line', 'bom_id', string='Components')

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('mcm.bom') or 'New'
        return super().create(vals)


class MCMBOMLine(models.Model):
    _name = 'mcm.bom.line'
    _description = 'BOM Component Line'

    bom_id = fields.Many2one('mcm.bom', string='BOM', ondelete='cascade')
    product_id = fields.Many2one('product.product', string='Component', required=True)
    quantity = fields.Float(string='Component Quantity', default=1.0)
