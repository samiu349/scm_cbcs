{
    'name': 'Factory Worker Entry System',
    'version': '1.0',
    'depends': ['base'],
    'data': [
        'security/ir.model.access.csv',
        'views/employes_views.xml',
        'report/report_action.xml',
        'report/report_template.xml',
    ],
    'installable': True,
    'application': True,
}
