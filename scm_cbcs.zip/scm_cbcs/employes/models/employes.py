from odoo import models, fields, api
import base64
import qrcode
from io import BytesIO


class Employes(models.Model):
    _name = 'employes'
    _description = 'Employes'

    name = fields.Char("Name")
    worker_code = fields.Char("Worker Code")
    phone = fields.Char("Phone")
    is_present = fields.Boolean("Is Present")

    qr_code_image = fields.Binary("QR Code", compute="_compute_qr_code", store=True)

    @api.depends('worker_code')
    def _compute_qr_code(self):
        for rec in self:
            if rec.worker_code:
                qr = qrcode.QRCode(
                    version=1,
                    box_size=10,
                    border=5
                )
                qr.add_data(rec.worker_code)
                qr.make(fit=True)
                img = qr.make_image(fill="black", back_color="white")
                buffer = BytesIO()
                img.save(buffer, format="PNG")
                rec.qr_code_image = base64.b64encode(buffer.getvalue())
            else:
                rec.qr_code_image = False

    def print_worker_report(self):
        return self.env.ref('employes.action_report_employes').report_action(self)
