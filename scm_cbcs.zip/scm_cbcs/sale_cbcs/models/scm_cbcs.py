from tokenize import String

from odoo import models, fields, api
from odoo.exceptions import UserError


class SaleOrderCbcs(models.Model):
    _name = 'sale.order.cbcs'
    _description = 'CBCS Sale Order'

    name = fields.Char(
        string="Order Reference",
        required=True,
        copy=False,
        readonly=True,
        default=lambda self: self.env['ir.sequence'].next_by_code('sale.order.cbcs')
    )

    partner_id = fields.Many2one('res.partner', string='Customer', required=True)
    date_order = fields.Datetime(string='Order Date', required=True, default=fields.Datetime.now)
    order_line_ids = fields.One2many('sale.order.cbcs.line', 'order_id', string='Order Lines')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirmed', 'Confirmed'),
        ('done', 'Done'),
    ], string='Status', default='draft', tracking=True)
    amount_untaxed = fields.Monetary(string='Untaxed Amount', compute='_compute_amount_all', store=True)
    amount_tax = fields.Monetary(string='Taxes', compute='_compute_amount_all', store=True)
    amount_total = fields.Monetary(string='Total', compute='_compute_amount_all', store=True)
    currency_id = fields.Many2one('res.currency', default=lambda self: self.env.company.currency_id.id)

    @api.depends('order_line_ids.price_total', 'order_line_ids.price_subtotal')
    def _compute_amount_all(self):
        for order in self:
            order.amount_untaxed = sum(line.price_subtotal for line in order.order_line_ids)
            order.amount_tax = sum(line.price_total - line.price_subtotal for line in order.order_line_ids)
            order.amount_total = order.amount_untaxed + order.amount_tax

    def action_confirm(self):
        for record in self:
            record.state = 'confirmed'

    def action_done(self):
        for record in self:
            record.state = 'done'

    def action_reset_draft(self):
        for record in self:
            record.state = 'draft'


class SaleOrderCbcsLine(models.Model):
    _name = 'sale.order.cbcs.line'
    _description = 'CBCS Sale Order Line'

    order_id = fields.Many2one('sale.order.cbcs', string='Order Reference', required=True, ondelete='cascade')
    product_id = fields.Many2one('product.product', string='Product', required=True)
    quantity = fields.Float(string='Quantity', default=1.0)
    price_unit = fields.Float(string='Unit Price', required=True)
    tax_id = fields.Many2one(
        'account.tax',
        string='Tax',
        domain=[('type_tax_use', '=', 'sale')]
    )

    currency_id = fields.Many2one(related='order_id.partner_id.currency_id', string="Currency", store=True)
    price_subtotal = fields.Monetary(string="Subtotal", compute='_compute_amount', store=True)
    price_total = fields.Monetary(string="Total", compute='_compute_amount', store=True)

    @api.depends('price_unit', 'quantity', 'tax_id')
    def _compute_amount(self):
        for line in self:
            taxes = line.tax_id.compute_all(
                price_unit=line.price_unit,
                currency=line.currency_id,
                quantity=line.quantity,
                product=line.product_id,
                partner=line.order_id.partner_id
            ) if line.tax_id else {
                'total_excluded': line.price_unit * line.quantity,
                'total_included': line.price_unit * line.quantity
            }

            line.price_subtotal = taxes['total_excluded']
            line.price_total = taxes['total_included']


def update_inventory_on_sale(self):
    inventory_model = self.env['inventory.stock.line']
    inventory = inventory_model.search([('product_id', '=', self.product_id.id)], limit=1)

    if inventory:
        # Reduce quantity, even if it goes negative
        inventory.quantity -= self.quantity
    else:
        # No inventory found → create with negative quantity
        inventory_model.create({
            'product_id': self.product_id.id,
            'quantity': -self.quantity,
        })


@api.model
def create(self, vals):
    record = super().create(vals)
    record.update_inventory_on_sale()
    return record
