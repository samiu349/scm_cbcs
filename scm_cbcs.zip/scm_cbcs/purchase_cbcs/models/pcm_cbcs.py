from odoo import models, fields, api


class PurchaseOrderCbcs(models.Model):
    _name = 'purchase.order.cbcs'
    _description = 'CBCS Purchase Order'

    name = fields.Char(string='Order Reference', required=True, copy=False, readonly=True, default='New')
    partner_id = fields.Many2one('res.partner', string='Vendor', required=True)
    currency_id = fields.Many2one('res.currency', default=lambda self: self.env.company.currency_id)

    order_line_ids = fields.One2many('purchase.order.cbcs.line', 'order_id', string='Order Lines')

    amount_untaxed = fields.Monetary(string='Untaxed Amount', compute='_compute_total', store=True)
    amount_total = fields.Monetary(string='Total', compute='_compute_total', store=True)

    date_order = fields.Date(string='Date')
    state = fields.Selection([
        ('draft', 'Draft'),
        ('confirm', 'Confirmed'),
        ('cancel', 'Cancelled')
    ], string='Status', default='draft', tracking=True)

    def action_confirm(self):
        for order in self:
            order.state = 'confirm'

    def action_cancel(self):
        for order in self:
            order.state = 'cancel'

    @api.depends('order_line_ids.price_subtotal')
    def _compute_total(self):
        for order in self:
            amount_untaxed = amount_total = 0.0
            currency = order.currency_id

            for line in order.order_line_ids:
                price_unit = line.price_unit
                qty = line.product_qty

                if line.tax_id:
                    tax_data = line.tax_id.compute_all(price_unit, currency=currency, quantity=qty)
                    amount_untaxed += tax_data['total_excluded']
                    amount_total += tax_data['total_included']
                else:
                    amount = price_unit * qty
                    amount_untaxed += amount
                    amount_total += amount

            order.amount_untaxed = amount_untaxed
            order.amount_total = amount_total


class PurchaseOrderCbcsLine(models.Model):
    _name = 'purchase.order.cbcs.line'
    _description = 'CBCS Purchase Order Line'

    order_id = fields.Many2one('purchase.order.cbcs', string='Order Reference', required=True)
    product_id = fields.Many2one('product.product', string='Product')
    product_qty = fields.Float(string='Quantity', default=1.0)
    price_unit = fields.Float(string='Unit Price')
    currency_id = fields.Many2one(related='order_id.currency_id', store=True, readonly=True)

    tax_id = fields.Many2one(
        'account.tax',
        string='Tax',
        domain=[('type_tax_use', '=', 'purchase')]
    )

    price_subtotal = fields.Monetary(string='Subtotal (Incl. Tax)', compute='_compute_subtotal', store=True)

    @api.depends('price_unit', 'product_qty', 'tax_id')
    def _compute_subtotal(self):
        for line in self:
            if line.tax_id:
                tax_data = line.tax_id.compute_all(line.price_unit, currency=line.currency_id,
                                                   quantity=line.product_qty)
                line.price_subtotal = tax_data['total_included']
            else:
                line.price_subtotal = line.price_unit * line.product_qty

    def update_inventory_on_purchase(self):
        inventory = self.env['inventory.stock.line'].search([('product_id', '=', self.product_id.id)], limit=1)
        if inventory:
            inventory.quantity += self.product_qty
        else:
            self.env['inventory.stock.line'].create({
                'product_id': self.product_id.id,
                'quantity': self.product_qty,
            })

    @api.model
    def create(self, vals):
        record = super().create(vals)
        record.update_inventory_on_purchase()
        return record
