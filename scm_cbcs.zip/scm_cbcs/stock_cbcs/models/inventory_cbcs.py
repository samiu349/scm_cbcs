from odoo import models, fields


class InventoryStockLine(models.Model):
    _name = 'inventory.stock.line'
    _description = 'Stock Line'

    product_id = fields.Many2one('product.product', string='Product')
    quantity = fields.Float(string='Quantity')
